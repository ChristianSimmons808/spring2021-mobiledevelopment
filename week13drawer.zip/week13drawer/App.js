import 'react-native-gesture-handler';
import React, {useState} from 'react';
import { View, Text } from 'react-native';
import { Button } from 'react-native-elements';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';

function HomeScreen(props) {
  return (
  <View style={{ flex: 1, alignItems: 'center', 
  justifyContent: 'center'}}>
  <Text>Home Screen</Text>
  <Button 
    title="Cardio Days"
    onPress={() => props.navigation.navigate('Cardio Day')}
  />
  <Button 
    title="Weight Days"
    onPress={() => props.navigation.navigate('Weight Day')}
  />
  </View>
  );
}

function CardioScreen(props){
  const [days, setDays] = useState(0);
  
    return(
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Cardio Days: {days}</Text>
            <Button title="Add Cardio Day"
            onPress={() => setDays(days + 1)}/>
            <Button title="Reset Counter" 
            onPress={() => setDays(0)}/>
            <Button
        title="Back to Home"
        onPress={() => props.navigation.navigate('Home')}
      />
        </View>
    );
}

class WeightScreen extends React.Component {
      constructor(props) {
        super(props);
        this.state = {
            days: 0
        };
    }

render() {
  
    return(
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Weight Days: {this.state.days}</Text>
            <Button title="Weight Day"
            onPress={() => this.setState({days: this.state.days + 1})}/>
            <Button title="Reset Counter" onPress={() => this.setState({days: 0})}/>
            <Button
        title="Back to Home"
        onPress={() => this.props.navigation.navigate('Home')}
      />
        </View>
    );
}
}
const Drawer = createDrawerNavigator();

function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator>
        <Drawer.Screen name="Home" component={HomeScreen} />
        <Drawer.Screen name="Cardio Day" component={CardioScreen} />
        <Drawer.Screen name="Weight Day" component={WeightScreen}/>
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

export default App;