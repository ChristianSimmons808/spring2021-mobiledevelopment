
import 'react-native-gesture-handler';
import React from 'react';
import { Text, View} from 'react-native';
import { Button } from 'react-native-elements';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {useState, setState} from 'react';

function HomeScreen(props) {
  return (
  <View style={{ flex: 1, alignItems: 'center', 
  justifyContent: 'center'}}>
  <Text>Home Screen</Text>
  <Button 
    title="Cardio Days"
    onPress={() => props.navigation.navigate('Cardio')}
  />
  <Button 
    title="Weight Days"
    onPress={() => props.navigation.navigate('Weight')}
  />
  </View>
  );
}

function CardioScreen(props){
  const [days, setDays] = useState(0);
  
    return(
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Cardio Days: {days}</Text>
            <Button title="Add Cardio Day"
            onPress={() => setDays(days + 1)}/>
            <Button title="Reset Counter" 
            onPress={() => setDays(0)}/>
            <Button
        title="Back to Home"
        onPress={() => props.navigation.navigate('Home')}
      />
        </View>
    );
}

class WeightScreen extends React.Component {
      constructor(props) {
        super(props);
        this.state = {
            days: 0
        };
    }

render() {
  
    return(
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <Text>Weight Days: {this.state.days}</Text>
            <Button title="Weight Day"
            onPress={() => this.setState({days: this.state.days + 1})}/>
            <Button title="Reset Counter" onPress={() => this.setState({days: 0})}/>
            <Button
        title="Back to Home"
        onPress={() => this.props.navigation.navigate('Home')}
      />
        </View>
    );
}
}



const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home"component={HomeScreen}/>
        <Stack.Screen name="Cardio" component={CardioScreen}/>
        <Stack.Screen name="Weight" component={WeightScreen}/>
      </Stack.Navigator>
   </NavigationContainer>
  );
}